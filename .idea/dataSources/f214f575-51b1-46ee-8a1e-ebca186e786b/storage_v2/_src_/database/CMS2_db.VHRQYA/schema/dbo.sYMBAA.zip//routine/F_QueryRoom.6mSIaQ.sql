--获取实验室日占用表此存储过程将返回整理过后的结果
CREATE PROC dbo.F_QueryRoom(
	@FindUsing BIT=1,					--1.查找指定时间段内有课的课室的占用情况  0.查找指定时间内有空闲的课室的占用情况
	@QueryWeek TINYINT,					--查找的星期数,从0开始编号,0为星期一
	@QueryClassWeek TINYINT,			--查找的周次,只支持单周查找(其取值为1-20)
	@TermID TINYINT=0,					--查找的学期的ID,默认值是当前数据库中设置的首选学期
	@BuildingName NVARCHAR(20)=N'%'		--查找的建筑的名称,默认值为查找所有的楼栋
) AS BEGIN
	SET NOCOUNT ON
	IF (@TermID=0)
		SELECT @TermID=CONVERT(INT,GValue) FROM dbo.GlobalInfo WHERE GName=N'CurTermID'
	ELSE BEGIN
		IF NOT EXISTS(SELECT * FROM dbo.TermInfo WHERE TID=@TermID) BEGIN
			RAISERROR(N'找不到指定的学期',16,1);
			RETURN
		END
	END
	DECLARE @TargetClassWeek INTEGER
	IF @QueryClassWeek BETWEEN 1 AND 20 BEGIN
		SET @TargetClassWeek=POWER(2,@QueryClassWeek-1);
	END ELSE BEGIN
		RAISERROR(N'查询的周次的范围应当为1-20之间',16,1);
		RETURN
	END
	SELECT DISTINCT R.RID, R.RName AS RName, C.CClTime AS ClTime INTO #tmp FROM dbo.CourseInfo AS C,dbo.RoomInfo AS R,dbo.BuildingInfo AS B
		WHERE C.TID=@TermID AND C.CWeek=@QueryWeek AND R.RID=C.RID AND R.BID=B.BID AND
			 (C.CClWeek&@QueryClassWeek)<>0 AND B.BName LIKE @BuildingName

	IF (@FindUsing = 0)
		INSERT #tmp SELECT DISTINCT R.RID, R.RName AS RName, 0 AS ClTime FROM dbo.RoomInfo AS R,dbo.BuildingInfo AS B
			WHERE B.BID=R.BID AND B.BName LIKE @BuildingName AND
				NOT EXISTS(SELECT * FROM dbo.CourseInfo AS C
					WHERE C.RID=R.RID AND C.TID=@TermID AND C.CWeek=@QueryWeek AND
						 (C.CClWeek&@TargetClassWeek)<>0 )

	IF (@FindUsing = 1)
		SELECT RID AS RoomID,RName AS RoomName,SUM(ClTime) AS ClassTime
			FROM #tmp GROUP BY RName,RID
	ELSE
		SELECT RID AS RoomID,RName AS RoomName,(SUM(ClTime)^16383) AS ClassTime
			FROM #tmp GROUP BY RName,RID
END


go

