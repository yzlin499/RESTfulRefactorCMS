--用于创建一个新的课室,如果创建成功,则返回一个新课室的ID,如果创建失败,则抛出错误
CREATE PROC dbo.F_CreateRoom(
	@RoomName	NVARCHAR(10),		--新建的课室的名称,如:MA309
	@BuildingName NVARCHAR(10),		--新建的教学楼的名称(如果数据库中不存在此教学楼,则会自动创建)
	@MaxStudentCount INTEGER,		--新建的课室的容量
	@UseFor NVARCHAR(20)=NULL		--新建的课室的用途
) AS BEGIN
	SET NOCOUNT ON
	DECLARE @BID TINYINT
	SELECT @BID=BID FROM dbo.BuildingInfo WHERE BName=@BuildingName
	IF @BID IS NULL BEGIN
		INSERT dbo.BuildingInfo(BName)VALUES(@BuildingName)
		SET @BID=@@IDENTITY
	END
	DECLARE @RID TINYINT
	SELECT @RID=RID FROM dbo.RoomInfo WHERE RName=@RoomName
	IF @RID IS NULL BEGIN
		INSERT dbo.RoomInfo(RName,BID,RMaxCount,RUseFor)VALUES(@RoomName,@BID,@MaxStudentCount,@UseFor);
		SET @RID=@@IDENTITY
	END
		SELECT @RID AS New_ID
	END
go

