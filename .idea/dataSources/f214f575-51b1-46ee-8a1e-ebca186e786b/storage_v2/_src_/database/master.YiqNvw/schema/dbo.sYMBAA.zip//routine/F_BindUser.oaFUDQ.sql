
CREATE PROC dbo.F_BindUser(			--绑定用户和某个值,比如微信ID,微信小程序ID
	@UserName NVARCHAR(20),			--用户名
	@BindType TINYINT,				--绑定的类别(此类别需要预先约定好)
	@BindValue NVARCHAR(50),		--绑定的值
	@PGroup TINYINT=0				--绑定的用户的用户组
) AS BEGIN
	SET NOCOUNT ON
	DECLARE @PID SMALLINT
	SELECT @PID=PID FROM dbo.PersonInfo WHERE @UserName=PUserName AND PGroup=@PGroup
	IF (@PID IS NULL) BEGIN
		RAISERROR(N'用户不存在',16,1);
		RETURN;
	END
	IF EXISTS(SELECT * FROM dbo.BindInfo WHERE BDValue= @BindValue AND BDType=@BindType AND PID<>@PID) BEGIN
		RAISERROR(N'此ID已经被绑定,请先解绑原来的账号',16,1);
		RETURN;
	END

	
	IF EXISTS(SELECT * FROM dbo.BindInfo WHERE PID=@PID AND BDType=@BindType)
		UPDATE dbo.BindInfo SET BDValue=@BindValue WHERE @PID=PID AND @BindType=BDType
	ELSE
		INSERT dbo.BindInfo(PID,BDType,BDValue)VALUES(@PID,@BindType,@BindValue)
	END
go

